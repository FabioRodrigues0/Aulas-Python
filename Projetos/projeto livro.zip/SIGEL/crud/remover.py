# Imports
import os
import re


def apagar_livro():

    apaga_isbn = int(input("Indique o ISBN do livro que pretende apagar: "))

