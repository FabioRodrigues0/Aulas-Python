# Imports
from pathlib import Path
import csv
import os
import pandas as pd
from tempfile import NamedTemporaryFile

# definiçao de variaveis
path_proj = Path.cwd()
file = f'{path_proj}\\bd.csv'
tempfile = NamedTemporaryFile(mode='w', delete=False)
header = ['Titulo', 'Autor', 'ISBN', 'Ano', 'Editora', 'Genero', 'Disponibilidade', 'Emprestado', 'Data_Devolução']


def add_livro(livro):
    with open(file, 'a', encoding='UTF8', newline='') as t:
        writer = csv.DictWriter(t, fieldnames=header)

        # write the data
        writer.writerow(livro)
    t.close()


def read_livro():
    dataframe = pd.read_csv(file)

    list_test = dataframe.to_dict('records')
    return list_test


def read_livro_param(txt):
    # create a dataframe
    df = pd.DataFrame(file, columns=header)

    # selecting rows based on condition
    rslt_df = df[df['ISBN'] == txt]
    return rslt_df.to_dict('records')


def read_livro_emp():
    # create a dataframe
    df = pd.DataFrame(file, columns=header)

    # selecting rows based on condition
    rslt_df = df[df['Disponivilidade'] == True]
    return rslt_df.to_dict('records')


def read_livro_dev():
    # create a dataframe
    df = pd.DataFrame(file, columns=header)

    # selecting rows based on condition
    rslt_df = df[df['Disponivilidade'] == False]
    return rslt_df.to_dict('records')


def updade_estado_livro(txt):
    with open(file, 'r') as csvfile, tempfile:
        new_dict = read_livro_param(txt)
        reader = csv.DictReader(csvfile, fieldnames=header)
        writer = csv.DictWriter(tempfile, fieldnames=header)
        for row in reader:
            if row['ISBN'] == txt:
                print('updating row\n', row)
            writer.writerow(new_dict)
    csvfile.close(), tempfile.close()
