import gestor
import listar


def devolucao_livro():
    lista = gestao_bd.read_livro_dev()
    listar.listagem(lista)
    isbn_devolucao = input("Digite o ISBN do livro a ser devolvido: ")
    gestao_bd.updade_estado_livro(isbn_devolucao)