import gestor


def listagem(lista=None):
    if lista is None:
        lista = []
    if lista:
        biblioteca = gestao_bd.read_livro()
        for livro in biblioteca:
            print(*(f'{k}: {v}' for k, v in livro.items()), sep='\n', end='\n\n')
    else:
        for livro in lista:
            print(*(f'{k}: {v}' for k, v in livro.items()), sep='\n', end='\n\n')

