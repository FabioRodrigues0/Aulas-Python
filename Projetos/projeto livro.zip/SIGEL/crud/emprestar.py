import gestor
import listar


def emprestar_livro():
    lista = gestao_bd.read_livro_emp()
    listar.listagem(lista)
    isbn_emprestimo = input("Digite o ISBN do livro a ser emprestado: ")
    gestao_bd.updade_estado_livro(isbn_emprestimo)