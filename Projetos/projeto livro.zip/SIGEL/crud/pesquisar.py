import gestor


def pesquisa():
    isbn = input('Indique o ISBN que pretende procurar:')
    biblioteca = gestao_bd.read_livro_param(isbn)
    for livro in biblioteca:
        if isbn in livro.values():
            print(livro)
            break
    else:
        print(f"Nenhum livro encontrado com o titulo: {isbn}")

