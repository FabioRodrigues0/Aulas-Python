import crud.remover as remove
import crud.adicionar as add
import crud.listar as listar
import crud.pesquisar as pesquisar
import crud.emprestar as emprestar
import crud.devolver as devolver

# Menu do programa
while True:
    print("[ 1 ] - Adicionar Livro")
    print("[ 2 ] - Remover Livro")
    print("[ 3 ] - Listar Livros")
    print("[ 4 ] - Procurar Livro")
    print("[ 5 ] - Emprestar Livro")
    print("[ 6 ] - Devolver Livro")
    print("[ 0 ] - Sair")

    try:
        opcao = input("Escolha uma opção: ")

        if opcao == "1":
            add.adicionar_livro()

        elif opcao == "2":
            remove.apagar_livro()

        elif opcao == "3":
            listar.listagem()

        elif opcao == "4":
            pesquisar.pesquisa()

        elif opcao == "5":
            emprestar.emprestar_livro()

        elif opcao == "6":
            devolver.devolucao_livro()

        elif opcao == "0":
            print("Saindo do programa. Até mais!")
            break

        else:
            print("Opção inválida. Tente novamente.")
    except Exception as e:
        print(f"Ocorreu um erro: {e}")







